package com.personal.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal
import java.math.RoundingMode

private val Bg = Color(0xFF090A0D)
private val Panel = Color(0xFF17191F)
private val Key = Color(0xFF242730)
private val Accent = Color(0xFFFF9F0A)
private val White = Color(0xFFF5F5F7)
private val Muted = Color(0xFF9A9DA7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9,10,13)
        window.navigationBarColor = android.graphics.Color.rgb(9,10,13)
        setContent { CalculatorScreen() }
    }
}

@Composable
fun CalculatorScreen() {
    var display by remember { mutableStateOf("0") }
    var stored by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<String?>(null) }
    var fresh by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(listOf<String>()) }

    fun format(n: Double): String {
        if (!n.isFinite()) return "Ошибка"
        return BigDecimal.valueOf(n).setScale(8, RoundingMode.HALF_UP)
            .stripTrailingZeros().toPlainString().take(16)
    }
    fun calculate() {
        val a = stored ?: return
        val b = display.toDoubleOrNull() ?: return
        val symbol = op ?: return
        val result = when (symbol) {
            "+" -> a + b
            "−" -> a - b
            "×" -> a * b
            "÷" -> if (b == 0.0) Double.NaN else a / b
            else -> b
        }
        val answer = format(result)
        history = (listOf("$a $symbol $b = $answer") + history).take(8)
        display = answer
        stored = null; op = null; fresh = true
    }
    fun press(value: String) {
        when (value) {
            "AC" -> { display = "0"; stored = null; op = null; fresh = false }
            "⌫" -> { display = if (fresh || display.length <= 1) "0" else display.dropLast(1); fresh = false }
            "+/−" -> if (display != "0" && display != "Ошибка") display =
                if (display.startsWith("-")) display.drop(1) else "-$display"
            "%" -> display = display.toDoubleOrNull()?.let { format(it / 100.0) } ?: "0"
            "." -> { if (fresh) { display = "0."; fresh = false } else if (!display.contains(".")) display += "." }
            "=" -> calculate()
            "+", "−", "×", "÷" -> {
                if (op != null && !fresh) calculate()
                stored = display.toDoubleOrNull()
                op = value
                fresh = true
            }
            else -> {
                if (display == "Ошибка" || fresh || display == "0") display = value
                else if (display.length < 14) display += value
                fresh = false
            }
        }
    }

    val rows = listOf(
        listOf("AC", "+/−", "%", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "−"),
        listOf("1", "2", "3", "+"),
        listOf("⌫", "0", ".", "=")
    )
    Column(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("МОЙ КАЛЬКУЛЯТОР", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.weight(1f))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(20.dp),
            horizontalAlignment = Alignment.End) {
            Text(if (stored != null && op != null) "${format(stored!!)} $op" else "ГОТОВО К РАСЧЁТАМ",
                color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Text(display, color = White, fontSize = if (display.length > 10) 36.sp else 48.sp,
                fontWeight = FontWeight.Light, textAlign = TextAlign.End, maxLines = 1)
        }
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { label ->
                    val isOp = label in listOf("÷", "×", "−", "+", "=")
                    val isUtility = label in listOf("AC", "+/−", "%", "⌫")
                    Button(
                        onClick = { press(label) },
                        modifier = Modifier.weight(1f).height(68.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isOp) Accent else if (isUtility) Color(0xFF383B44) else Key,
                            contentColor = if (isOp) Color.Black else White
                        ),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(label, fontSize = if (label.length > 2) 17.sp else 25.sp,
                            fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        if (history.isNotEmpty()) {
            Text("ПОСЛЕДНИЕ РАСЧЁТЫ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            history.take(3).forEach { Text(it, color = Muted, fontSize = 12.sp) }
        }
        Spacer(Modifier.height(4.dp))
    }
}
